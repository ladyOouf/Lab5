# Javascript Image Slider
Html, Css and Javascript Image Slider with control buttons

[Live Preview](https://skcals.github.io/javascript_image_slider)
